import requests as rq
from bs4 import BeautifulSoup
import csv

csvfile= open('fakeNewsdata.csv', 'a', encoding='utf-8-sig', newline='')
writer = csv.writer(csvfile)
writer.writerow(["title", "content"])


def crolling(url):
    req = rq.get(url)
    soup = BeautifulSoup(req.text,"html.parser")
    title=soup.find("h2",attrs={"id":"title_area"}).get_text()
    content=soup.find("article",attrs={"id":"dic_area"}).get_text()
    test=content.split("\n")[0]
    return test


'''URL=open("파일명","r")
for i in range():#크롤링할 갯수 집어 넣기
    url=URL.readline()
'''
#저장할 데이터 셋
data_s=[]

infile=open("테스트 데이터/FNL.txt","r",encoding="utf-8")#파일경로,여는 형식
for i in infile:
#url=" https://n.news.naver.com/mnews/article/001/0015074952?sid=104"
    url=infile.readline()
    url=url.strip()
    req = rq.get(url)
    soup = BeautifulSoup(req.text,"html.parser")
    title=soup.find("h2",attrs={"style":"margin:0;color:black;font-size:24px;font-weight:bold;letter-spacing:-0.5px;line-height:33px;font-family: 'Noto Sans KR', sans-serif;  font-optical-sizing: auto;  font-weight: 500;"}).get_text()

    i=1
    article = soup.find("h4", attrs={'style':"color:black;font-size:1.2em;font-weight:normal;letter-spacing:-1px;padding-top:0;line-height:180%"})
    

    if article:
        # strong제거 (원하면 태그 추가 가능)
        for tag in article.find_all(["strong","em"]):
            tag.decompose()

        content = article.get_text(separator="\n").strip()
        i=0



#content=soup.find("article",attrs={"id":"dic_area"}).get_text(separator="\n")



    test=content.split("\n")[i:i+3]
    test=" ".join(test)

    data_s.append([title,test])
print(data_s[1])
for i in range(len(data_s)):
    writer.writerow((data_s[i][0],data_s[i][1]))

