#라이브러리 정의
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report
import re
import string

def wordopt(text):
    text = text.lower()
    text = re.sub('\[.*?\]', '', text)
    text = re.sub("\\W"," ",text) 
    text = re.sub('https?://\S+|www\.\S+', '', text)
    text = re.sub('<.*?>+', '', text)
    text = re.sub('[%s]' % re.escape(string.punctuation), '', text)
    text = re.sub('\n', '', text)
    text = re.sub('\w*\d\w*', '', text)    
    return text


#데이터셋 가져오기(상대경로를 이용하므로 같은 폴더에 저장해둘것)
df_fake = pd.read_csv("fakeNewsdata.csv")
df_true = pd.read_csv("trueNewsdata.csv")

#각각의 데이터셋에 class라는 새로운 열을 추가해서 fake는 0이라는 값으로 Fake라는 값을 가지게 되고 true는 1이라는 값으로 True라는 값을 가지게 한다
df_fake["class"] = 0
df_true["class"] = 1

#데이터 중 어느정도를 테스트 데이터로 사용할지 지정함

df_fake_manual_testing = df_fake.tail(10)#여기 10의 숫자와 아래 for문의 시작값과 종료값의 차이를 같게하여 그 크기 만큼 테스트 데이터로 사용하기 위한 전처리
for i in range(40,57,-1):
    df_fake.drop([i], axis = 0, inplace = True)


df_true_manual_testing = df_true.tail(10)
for i in range(20,29,-1):
    df_true.drop([i], axis = 0, inplace = True)

#각각의 데이터셋에 class라는 새로운 열을 추가해서 fake는 0이라는 값으로 Fake라는 값을 가지게 되고 true는 1이라는 값으로 True라는 값을 가지게 한다
df_fake_manual_testing["class"] = 0
df_true_manual_testing["class"] = 1

#fake데이터와true데이터를 합쳐 하나의 테스트 데이터로 만들고 csv파일로 만듦
df_manual_testing = pd.concat([df_fake_manual_testing,df_true_manual_testing], axis = 0)
df_manual_testing.to_csv("manual_testing.csv")


#비선형 학습을 하기위해선 true와 fake데이터를 모두 학습해야함.(따라서 두 데이터셋을 합치는것)
df_merge = pd.concat([df_fake, df_true], axis =0 )




#필요없는 데이터 columns를 삭제함
#df = df_merge.drop(["title"], axis = 1)#class colums도 삭제해야하니 본 모델 돌릴때는 넣을것

#데이터셋을 무작위로 설정함
#df = df.sample(frac = 1)
df = df_merge.sample(frac = 1)

#인덱스 초기화
#인덱스를 초기화하고 새 column을 추가?
df.reset_index(inplace = True)
#
df.drop(["index"], axis = 1, inplace = True)

df["title"]=df['title'].apply(wordopt)
df["content"] = df["content"].apply(wordopt)

x = df["title"]+df["content"]
y = df["class"]

#데이터셋,학습셋을 나눔
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.25)

#데이터 벡터화 과정
from sklearn.feature_extraction.text import TfidfVectorizer

vectorization = TfidfVectorizer()
xv_train = vectorization.fit_transform(x_train)
xv_test = vectorization.transform(x_test)

from sklearn.linear_model import LogisticRegression

LR = LogisticRegression()
LR.fit(xv_train,y_train)

pred_lr=LR.predict(xv_test)

LR.score(xv_test, y_test)

print(classification_report(y_test, pred_lr))

from sklearn.tree import DecisionTreeClassifier

DT = DecisionTreeClassifier()
DT.fit(xv_train, y_train)

pred_dt = DT.predict(xv_test)

print(classification_report(y_test, pred_dt))

from sklearn.ensemble import GradientBoostingClassifier

GBC = GradientBoostingClassifier(random_state=0)
GBC.fit(xv_train, y_train)

pred_gbc = GBC.predict(xv_test)

print(classification_report(y_test, pred_gbc))


from sklearn.ensemble import RandomForestClassifier

RFC = RandomForestClassifier(random_state=0)
RFC.fit(xv_train, y_train)

pred_rfc = RFC.predict(xv_test)

print(classification_report(y_test, pred_rfc))

def output_lable(n):
    if n == 0:
        return "가짜뉴스입니다"
    elif n == 1:
        return "가짜뉴스가 아닙니다"

def manual_testing(news):
    testing_news = {"text":[news]}
    new_def_test = pd.DataFrame(testing_news)
    new_def_test["text"] = new_def_test["text"].apply(wordopt)
    new_x_test = new_def_test["text"]
    new_xv_test = vectorization.transform(new_x_test)
    pred_LR = LR.predict(new_xv_test)
    pred_DT = DT.predict(new_xv_test)
    pred_GBC = GBC.predict(new_xv_test)
    pred_RFC = RFC.predict(new_xv_test)

    return print("\n\nLR Prediction: {} \nDT Prediction: {} \nGBC Prediction: {} \nRFC Prediction: {}".format(output_lable(pred_LR[0]),                                                                                                       output_lable(pred_DT[0]),
                                                                                                              output_lable(pred_GBC[0]),
    
                                                                                                              output_lable(pred_RFC[0])))

news=""
while news != "0":
    title = str(input("뉴스의 제목을 입력해주세요 : "))
    news = str(input("뉴스의 내용을 입력해주세요 : "))
    manual_testing(news)


