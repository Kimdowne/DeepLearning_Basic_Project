import json
import csv
import os

folder_path = './학습 데이터 셋/SampleData'
file_list = os.listdir(folder_path)

csvfile = open('Learning_data.csv', 'a', encoding='utf-8-sig', newline='')
writer = csv.writer(csvfile)
writer.writerow(["title", "content", "class"])   # class 컬럼 추가

for file_name in file_list:
    file_path = os.path.join(folder_path, file_name)

    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    # title 추출
    title = data["sourceDataInfo"]["newsTitle"]

    # sentenceNo 1~3의 content 합치기
    sentences = data["sourceDataInfo"]["sentenceInfo"]
    merged_content = " ".join(
        s["sentenceContent"] for s in sentences if 1 <= s["sentenceNo"] <= 3
    )

    # useType → class 매핑
    use_type = data["sourceDataInfo"]["useType"]  # useType 추출

    if use_type == 1:
        class_value = 0
    elif use_type == 0:
        class_value = 1
    else:
        class_value = -1  # 예상 밖 값 처리(필요 없으면 제거 가능)

    # 출력 확인
    print(title)
    print(merged_content)
    print("class:", class_value)

    # CSV 파일 저장
    writer.writerow([title, merged_content, class_value])