import requests as rq
from bs4 import BeautifulSoup
import csv

csvfile= open('trueNewsdata.csv', 'a', encoding='utf-8-sig', newline='')
writer = csv.writer(csvfile)
writer.writerow(["title", "content"])

def crolling(url):
    req = rq.get(url)
    soup = BeautifulSoup(req.text,"html.parser")
    title=soup.find("h2",attrs={"id":"title_area"}).get_text()
    content=soup.find("article",attrs={"id":"dic_area"}).get_text()
    test=content.split("\n")[0]
    return test


'''URL=open("파일명","r")
for i in range():#크롤링할 갯수 집어 넣기
    url=URL.readline()
'''
#저장할 데이터 셋
data_s=[]

infile=open("테스트 데이터/TNL.txt","r")#파일경로,여는 형식
for i in infile:
#url=" https://n.news.naver.com/mnews/article/001/0015074952?sid=104"
    url=infile.readline()
    url=url.strip()
    req = rq.get(url)
    soup = BeautifulSoup(req.text,"html.parser")
    title=soup.find("h2",attrs={"id":"title_area"}).get_text()

    i=1
    article = soup.find("article", id="dic_area")

    if article:
        # strong, span 제거 (원하면 태그 추가 가능)
        for tag in article.find_all(["strong","em"]):
            tag.decompose()

        content = article.get_text(separator="\n").strip()
        i=0



#content=soup.find("article",attrs={"id":"dic_area"}).get_text(separator="\n")



    test=content.split("\n")[i:i+3]
    test=" ".join(test)

    data_s.append([title,test])
print(data_s)
for i in range(len(data_s)):
    writer.writerow((data_s[i][0],data_s[i][1]))